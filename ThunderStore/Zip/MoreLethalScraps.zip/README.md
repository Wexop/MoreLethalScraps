Add common lethal company monsters or anything in the game as scraps items (Be careful it can be noisy!)

Every spawn rate can be configured with LethalConfig !

Current scraps items:

- DogToy
- BrackenToy
- NutCrackerToy
- GiantToy
- OldBirdToy
- BlobToy
- FireExitToy
- GoldenFireExitToy
- JesterToy
- CoilHeadToy
- BugToy