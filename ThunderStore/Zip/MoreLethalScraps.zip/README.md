Add common lethal company monsters or anything in the game as scraps items (Be carefulf it can be noisy!)

Every spawn rate can be configured with LethalConfig !

Current item in v1.0.3:

- DogToy
- BrackenToy
- NutCrackerToy
- GiantToy
- OldBirdToy
- BlobToy
- FireExitToy
- GoldenFireExitToy